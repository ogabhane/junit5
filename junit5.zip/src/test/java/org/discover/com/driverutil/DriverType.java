package com.firstdata.aem.cucumber.common.driverutil;

public enum  DriverType {
    CHROME,
    FIREFOX,
    OPERA,
    EDGE,
    IE
}
