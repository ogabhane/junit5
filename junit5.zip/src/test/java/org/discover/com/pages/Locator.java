package org.discover.com.pages;

public enum Locator {
    ByClass,ByXpath,ByCss,ByTag,ByName
}
