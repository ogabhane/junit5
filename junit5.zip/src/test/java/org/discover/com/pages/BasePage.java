package org.discover.com.pages;

import org.discover.com.config.AppConfig;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public abstract class BasePage {

    private WebDriver driver;

    @Autowired
    private AppConfig reader;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        reader = context.getBean(AppConfig.class);
    }

    public void navigateTo() {
        driver.get(reader.getUrl());
    }

    public WebDriver driver() {
        return driver;
    }

    public BasePage setText(String selector, String text) {
        element(selector).sendKeys(text);
        return this;
    }

    public BasePage setText(String selector, String text, Locator type) {
        element(selector, type).sendKeys(text);
        return this;
    }

    public String getText(String selector) {
        return getText(selector, Locator.ByXpath);
    }

    public String getText(String selector, Locator type) { return element(selector, type).getText();}

    public String getText(WebElement parentElm,String subSelector, Locator type){
        WebElement subElement = element(parentElm, subSelector, type);
        return subElement.getText();
    }

    public String getText(WebElement elm){return elm.getText();}

    public WebElement element(String selector) {return element(selector, Locator.ByXpath);}

    public WebElement element(String selector, Locator by) { return driver().findElement(locator(selector, by)); }

    public WebElement element(WebElement parentElm, String subSelector, Locator by){return parentElm.findElement(locator(subSelector,by));}

    public List<WebElement> elements(String selector) { return driver().findElements(locator(selector, Locator.ByXpath)); }

    public List<WebElement> elements(String selector, Locator by) { return driver().findElements(locator(selector, by)); }

    public By locator(String selector, Locator by) {
        switch (by) {
            case ByCss:
                return org.openqa.selenium.By.cssSelector(selector);
            case ByTag:
                return org.openqa.selenium.By.tagName(selector);
            case ByName:
                return org.openqa.selenium.By.name(selector);
            case ByClass:
                return org.openqa.selenium.By.className(selector);
            default:
                return org.openqa.selenium.By.xpath(selector);
        }
    }
}
