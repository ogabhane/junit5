package org.discover.com.pages;

import org.openqa.selenium.WebDriver;


public class RecordListPage extends BasePage {
    public RecordListPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public RecordListPage setText(String selector, String text) {
        super.setText(selector, text);
        return this;
    }
}
