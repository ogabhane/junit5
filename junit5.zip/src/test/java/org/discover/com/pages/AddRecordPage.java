package org.discover.com.pages;

import org.openqa.selenium.WebDriver;


public class AddRecordPage extends BasePage {
    public AddRecordPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public AddRecordPage setText(String selector, String text) {
        super.setText(selector, text);
        return this;
    }

    public AddRecordPage click(String selector, Locator locator){
        element(selector,locator).click();
        return this;
    }
}
