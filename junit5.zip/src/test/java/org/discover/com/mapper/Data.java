package org.discover.com.mapper;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class Data {
    @JsonProperty("TestId")
    private String testId;
    @JsonProperty("Functionality")
    private String functionality;
    @JsonProperty("ClientNodeId")
    private String clientNodeId;
    @JsonProperty("ClientNodeDescription")
    private String clientNodeDescription;
    @JsonProperty("PartialChipIndicator")
    private String partialChipIndicator;
    @JsonProperty("ClientNodeIdFilter")
    private String clientNodeIdFilter;

    public String getTestId() {
        return testId;
    }

    public Data setTestId(String testId) {
        this.testId = testId;
        return this;
    }

    public String getFunctionality() {
        return functionality;
    }

    public Data setFunctionality(String functionality) {
        this.functionality = functionality;
        return this;
    }

    public String getClientNodeId() {
        return clientNodeId;
    }

    public Data setClientNodeId(String clientNodeId) {
        this.clientNodeId = clientNodeId;
        return this;
    }

    public String getClientNodeDescription() {
        return clientNodeDescription;
    }

    public Data setClientNodeDescription(String clientNodeDescription) {
        this.clientNodeDescription = clientNodeDescription;
        return this;
    }

    public String getPartialChipIndicator() {
        return partialChipIndicator;
    }

    public Data setPartialChipIndicator(String partialChipIndicator) {
        this.partialChipIndicator = partialChipIndicator;
        return this;
    }

    public String getClientNodeIdFilter() {
        return clientNodeIdFilter;
    }

    public Data setClientNodeIdFilter(String clientNodeIdFilter) {
        this.clientNodeIdFilter = clientNodeIdFilter;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if(super.equals(o)) return true;
        if(!(o instanceof Data)) return false;
        Data expectedData = (Data) o;
        return Objects.equals(testId,expectedData.testId) &&
                Objects.equals(clientNodeId,expectedData.clientNodeId) &&
                Objects.equals(clientNodeDescription,expectedData.clientNodeDescription) &&
                Objects.equals(clientNodeIdFilter,expectedData.clientNodeIdFilter) &&
                Objects.equals(partialChipIndicator,expectedData.partialChipIndicator);

    }

    @Override
    public String toString() {
        return "Data{" +
                "testId='" + testId + '\'' +
                ", functionality='" + functionality + '\'' +
                ", clientNodeId='" + clientNodeId + '\'' +
                ", clientNodeDescription='" + clientNodeDescription + '\'' +
                ", partialChipIndicator='" + partialChipIndicator + '\'' +
                ", clientNodeIdFilter='" + clientNodeIdFilter + '\'' +
                '}';
    }
}
