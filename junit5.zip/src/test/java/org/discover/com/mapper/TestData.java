package org.discover.com.mapper;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class TestData{
    @JsonProperty("TestData")
    public List<Data> testData;
}
