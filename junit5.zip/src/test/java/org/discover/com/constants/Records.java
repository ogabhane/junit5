package org.discover.com.constants;

public class Records {
    public static final String ID = "TestId";
    public static final String CLIENT_NODE_DESCRIPTION = "ClientNodeDescription";
    public static final String CLIENT_NODE_ID = "ClientNodeId";
    public static final String FILTER = "ClientNodeIdFilter";
    public static final String PARTIAL_CHIP_INDICATOR = "PartialChipIndicator";
}
