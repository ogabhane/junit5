package org.discover.com.extension;

import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.api.extension.ExtensionContext.Namespace;

import java.lang.reflect.Parameter;

public class InputExtension implements BeforeAllCallback,ParameterResolver{
    private static final Namespace NAMESPACE = Namespace.create(InputExtension.class);
    @Override

    public void beforeAll(ExtensionContext context) {
        Class<?> clazz = context.getRequiredTestClass();
        Input inp = clazz.getAnnotation(Input.class);

        InputDetails inputDetails = new InputDetails()
                .setPropertyFile(inp.property())
                .setJsonFile(inp.json())
                .setFeature(inp.feature())
                .setStoryClass(clazz);

        context.getStore(NAMESPACE).put(clazz.getName(), inputDetails);
    }

    public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext) throws ParameterResolutionException {
        Parameter parameter = parameterContext.getParameter();
        return InputDetails.class.equals(parameter.getType());
    }


    public Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext) throws ParameterResolutionException {
        return getStoryDetails(extensionContext);
    }

    private static InputDetails getStoryDetails(ExtensionContext context) {
        Class<?> clazz = context.getRequiredTestClass();
        return context.getStore(NAMESPACE).get(clazz.getName(), InputDetails.class);
    }
}