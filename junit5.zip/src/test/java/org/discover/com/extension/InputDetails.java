package org.discover.com.extension;

import java.util.HashMap;
import java.util.Map;

public class InputDetails {
    private String propertyFile;
    private String jsonFile;
    private String feature;
    public Class<?> storyClass;

    private Map<String, Object> store;

    public InputDetails() {
        store = new HashMap<>();
    }

    public String getPropertyFile() {
        return propertyFile;
    }

    public InputDetails setPropertyFile(String propertyFile) {
        this.propertyFile = propertyFile;
        return this;
    }

    public String getJsonFile() {
        return jsonFile;
    }

    public InputDetails setJsonFile(String jsonFile) {
        this.jsonFile = jsonFile;
        return this;
    }

    public Class<?> getStoryClass() {
        return storyClass;
    }

    public InputDetails setStoryClass(Class<?> storyClass) {
        this.storyClass = storyClass;
        return this;
    }

    public String getFeature() {
        return feature;
    }

    public InputDetails setFeature(String feature) {
        this.feature = feature;
        return this;
    }

    public String getClassName() {
        return storyClass.getName();
    }

    public Map<String, Object> getStore() {
        return store;
    }
}