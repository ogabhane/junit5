package org.discover.com.tests;

import io.github.bonigarcia.seljup.SeleniumExtension;
import org.discover.com.extension.Input;
import org.discover.com.extension.InputDetails;
import org.discover.com.extension.InputExtension;
import org.discover.com.mapper.Data;
import org.discover.com.pages.Locator;
import org.discover.com.pages.AddRecordPage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith({SeleniumExtension.class,InputExtension.class})
@Input(property = "locators/locator.properties", json = "actions/element.json")
@DisplayName("As a user, I will add record and verify if entry is displayed in table")
public class HomeTest extends BaseTest {
    private AddRecordPage page;

    public HomeTest(ChromeDriver driver, InputDetails details) {
        super(driver, details);
        this.page = getPage(AddRecordPage.class);

    }

    @BeforeEach
    public void navigateTo(){
        this.page.navigateTo();
    }

    @ParameterizedTest
    @DisplayName("Add records with testID-TD01")
    @CsvSource({"Add Record, ByName"})
    public void addRecord(String functionality, Locator locator) throws IOException, ClassNotFoundException {
       Data expected = getData(functionality);
       Data actual = new RecordTest(driver(),getProperties())
                .getRecord("tbody > tr", getLocator("ClientNodeId"),
                        "A", Locator.ByCss);

       assertEquals(expected,actual,"data should be matched");
    }
}
