package org.discover.com.tests;

import org.discover.com.constants.Records;
import org.discover.com.extension.Input;
import org.discover.com.extension.InputDetails;
import org.discover.com.extension.InputExtension;
import org.discover.com.mapper.Data;
import org.discover.com.pages.Locator;
import org.discover.com.pages.RecordListPage;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.discover.com.constants.Records.*;


@ExtendWith(InputExtension.class)
@Input(property = "locators/locator.properties", json = "actions/element.json")
public class RecordTest extends BaseTest{
    private RecordListPage page;

    public RecordTest(WebDriver driver, Properties details) {
        super(driver, details);
        this.page = getPage(RecordListPage.class);
    }

    public RecordTest(WebDriver driver){
        super(driver);
        this.page = getPage(RecordListPage.class);
    }


    public List<Data> getRecords(String selector, Locator Locator){
        List<Data> dataList = new ArrayList<>();
        page.elements(selector, Locator).stream().forEach(elm->{
            Data expectedData = new Data();
            expectedData.setTestId(page.getText(elm,getLocator(ID), Locator))
                    .setClientNodeDescription(page.getText(elm,getLocator(CLIENT_NODE_DESCRIPTION), Locator))
                    .setClientNodeId(page.getText(elm,getLocator(CLIENT_NODE_ID), Locator))
                    .setClientNodeIdFilter(page.getText(elm,getLocator(FILTER), Locator))
                    .setPartialChipIndicator(page.getText(elm,getLocator(PARTIAL_CHIP_INDICATOR), Locator));
            dataList.add(expectedData);

        });
        return dataList;
    }

    public Data getRecord(String parentSelector, String childSelector, String valueOfChildSelector, Locator locator){
        WebElement row = page.elements(parentSelector, locator).stream().filter(
                elm-> page.getText(page.element(elm,childSelector, locator)).equalsIgnoreCase(valueOfChildSelector)).findFirst().get();
        Data expectedData = new Data();
        expectedData.setTestId(page.getText(row,getLocator(ID), locator))
                .setClientNodeDescription(page.getText(row,getLocator(CLIENT_NODE_DESCRIPTION), locator))
                .setClientNodeId(page.getText(row,getLocator(CLIENT_NODE_ID), locator))
                .setClientNodeIdFilter(page.getText(row,getLocator(Records.FILTER), locator))
                .setPartialChipIndicator(page.getText(row,getLocator(PARTIAL_CHIP_INDICATOR), locator));
        return expectedData;
    }
}
