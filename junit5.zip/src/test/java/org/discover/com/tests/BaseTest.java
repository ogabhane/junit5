package org.discover.com.tests;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;
import com.google.gson.JsonParseException;
import org.discover.com.extension.InputDetails;
import org.discover.com.mapper.Data;
import org.discover.com.mapper.TestData;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Optional;
import java.util.Properties;

public class BaseTest {
    private final WebDriver driver;
    private InputDetails input;
    private Properties properties;

    public BaseTest(WebDriver driver) {
        this.driver = driver;
    }

    public BaseTest(WebDriver driver,InputDetails details) {
        this.driver = driver;
        this.input = details;
        this.properties =locator();
    }
    public BaseTest(WebDriver driver,Properties properties) {
        this.driver = driver;
        this.properties = properties;
    }
    public WebDriver driver(){
        return driver;
    }
    public <T> T getPage(Class<T> pageClassProxy){
        return PageFactory.initElements(driver, pageClassProxy);
    }

    private Properties locator(){
        return Optional.of(new Properties()).map(p->{try{p.load(new FileInputStream(getResourceFile(input.getPropertyFile())));}catch(IOException e){}return p;}).get();
    }

    public Properties getProperties() {
        return properties;
    }

    public String getLocator(String key){
        return properties.getProperty(key);
    }

    private <T> T json(Class<T> target) throws JsonParseException, JsonMappingException, IOException, ClassNotFoundException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(getResourceFile(input.getJsonFile()), objectMapper.getTypeFactory().constructType(Class.forName(target.getName())));
    }

   public Data getData(String functionality) throws IOException, ClassNotFoundException {
       return json(TestData.class).testData.stream().filter(data ->data.getFunctionality().contains(functionality)).findFirst().get();
   }

    public Data getData(int index) throws IOException, ClassNotFoundException {
        return json(TestData.class).testData.get(index);
    }

    public File getResourceFile(String absolutePath){
        return new File(Resources.getResource(absolutePath).getFile());
    }

}
