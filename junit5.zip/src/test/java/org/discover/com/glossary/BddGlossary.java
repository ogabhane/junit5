package com.firstdata.aem.cucumber.common.glossary;

import com.firstdata.aem.cucumber.common.utils.ResourceFileUtils;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

/**
 * A lookup glossary to allow human readable text in place of system values
 */

public class BddGlossary {

    private static final Type HASH_MAP_TYPE = new TypeToken<HashMap<String, Object>>() {
    }.getType();

    private static final String SOURCE_PATH = "common/glossary";

    private static final Map<String, Object> terms = new HashMap<>();

    /**
     * Default constructor
     */
    private BddGlossary() {
        // Blank constructor
    }

    static {
        buildTerms();
    }

    /**
     * Get the value from the glossary by the term (key).
     *
     * @param term the key in the glossary
     * @return the key's value in the glossary, or the key if does not match any in the glossary
     */
    public static String getGlossaryTerm(String term) {
        Object object = terms.get(term);

        if (object instanceof String) {
            return (String) object;
        }

       //log.warn("Glossary term entry '{}' is not found.", term);
        return term;
    }

    private static void buildTerms() {
        List<String> resourceFiles = ResourceFileUtils.getResourceFilesForDirectory(SOURCE_PATH);

        resourceFiles.forEach(item -> terms.putAll(covertJsonFileToMap(item)));
    }

    private static Map<String, Object> covertJsonFileToMap(String glossaryPath) {
        Map<String, Object> newMap = new HashMap<>();

        String jsonString = ResourceFileUtils.fileContentsToString(glossaryPath);

        if (isNotBlank(jsonString)) {
            newMap = new Gson().fromJson(jsonString, HASH_MAP_TYPE);
        }

        return newMap;
    }
}

