package com.firstdata.aem.cucumber.common.glossary.transformer;

import com.firstdata.aem.cucumber.common.glossary.BddGlossary;
import cucumber.api.Transformer;
/**
 * String Glossary Transformer
 */
public class StringGlossaryTransformer extends Transformer<String> {
    /***
     * Converts a String value from the original value to the corresponding value stored in the glossary.
     *
     * @param value the parameter value.
     * @return the transformed string.
     */
    @Override
    public String transform(String value) {
        return BddGlossary.getGlossaryTerm(value);
    }

}

