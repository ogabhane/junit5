package com.firstdata.aem.cucumber.common.glossary.annotation;


import com.firstdata.aem.cucumber.common.glossary.transformer.StringGlossaryTransformer;
import cucumber.api.Transform;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Glossary String annotation
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PARAMETER, ElementType.FIELD})
@Transform(StringGlossaryTransformer.class)
public @interface Glossary {
}

