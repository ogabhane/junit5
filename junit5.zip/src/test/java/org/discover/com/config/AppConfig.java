package org.discover.com.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.AbstractEnvironment;

@Configuration
@PropertySource(value = "classpath:config.properties")
public class AppConfig {

    @Autowired
    AbstractEnvironment environment;

    public String getUrl(){
        return environment.getProperty("url");
    }

    public String getUser(){ return  environment.getProperty("user");}
}
